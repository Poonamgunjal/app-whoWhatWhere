var gulpApp = angular.module('gulpApp',['ui.router','ngMap'])
    .service('loadData');


gulpApp.config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/GoogleMap');

    $stateProvider

    // HOME STATES AND NESTED VIEWS ========================================
        .state('GoogleMap', {
            url: '/GoogleMap',
            params:{
                name:'',
                index:''
            },
            resolve: {
                $fourSquareData: [ '$stateParams', 'loadData', function ($stateParams, loadData) {
                    $stateParams.name = $stateParams.name == '' ? 'montreal' : $stateParams.name;
                    return  loadData.retrieveFourSquare($stateParams.name);
                }],
                $yelpData: [ '$stateParams', 'loadData', function ($stateParams, loadData) {
                    $stateParams.name = $stateParams.name == '' ? 'montreal' : $stateParams.name;
                    var index = $stateParams.index == '' ? 0 : $stateParams.index;
                    var callbackId = 'angular.callbacks._'+ index.toString();
                    return  loadData.retrieveYelp($stateParams.name,callbackId);
                }]
            },
        })

        // ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
        .state('about', {
            // we'll get to this in a bit
        });

});