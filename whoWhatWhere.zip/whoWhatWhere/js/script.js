angular.module('appMaps', ['uiGmapgoogle-maps'])
    .controller('mainCtrl', function($scope,$rootScope, $timeout, $log,$q, $http) {
        $scope.location='';
        $scope.type='';
        $scope.listItems = [];
        $scope.imageName=[];
        $scope.cityMarkers=[];

        var results = this;
        $http.get("https://api.foursquare.com/v2/venues/search?" +
            "client_id=FHNVW0RNM0MK5WT1HEA1V2BHYFPIJNP2Y3HNV05BFVZDFZ0E&" +
            "client_secret=M1BDWESYNYZOETXW1OFWMVRVW4CPJV2IWIRWJE3FSUWHDZFQ&" +
            "v=20160907&ll=36.778261,-119.41793239999998&query=restaurants")
            .success(function(data){
                results = data;
                displayData(results);
            });
        $scope.map = {center: {latitude: 36.778261, longitude: -119.41793239999998}, zoom: 2 };
        $scope.options = {scrollwheel: false};
        $scope.coordsUpdates = 0;
        $scope.dynamicMoveCtr = 0;

        function displayData(result){
            $scope.position=['0,0'];
            $scope.cityMarkers=[''];
            var cnt=0;
            var elements=result.response.venues;
            for(var i=0;i<elements.length;i++){
                var geocoder = new google.maps.Geocoder();
                $scope.listItems[i]=elements[i];
                var address=elements[i].location.formattedAddress[0]+elements[i].location.formattedAddress[1];
                geocoder.geocode( { 'address': address}, function(results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        for(var i=0;i<results.length;i++) {
                            $scope.position[cnt]=(results[i].geometry.viewport.f.f+','+results[i].geometry.viewport.b.f);
                            var marker = {
                                id: cnt,
                                latitude: results[i].geometry.viewport.f.f,
                                longitude: results[i].geometry.viewport.b.f,
                                title: 'marker'+cnt,
                                showWindow: false,
                                panTo:true,
                                icon: './images/pin.png'
                            };

                            $scope.cityMarkers.push(marker);
                            $scope.$watchCollection("marker.coords", function (newVal, oldVal) {
                                if (_.isEqual(newVal, oldVal))
                                    return;
                                $scope.coordsUpdates++;
                            });
                            cnt++;
                        }
                    }
                });
            }
        }
        $scope.searchClick = function () {
          getLocation();
        };

        var getLocation =  function() {
            var geocoder = new google.maps.Geocoder();
            geocoder.geocode( { 'address': $scope.location}, function(results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    $rootScope.latitude = results[0].geometry.location.lat();
                    $rootScope.longitude = results[0].geometry.location.lng();
                    var results = this;
                    $http.get("https://api.foursquare.com/v2/venues/search?" +
                        "client_id=FHNVW0RNM0MK5WT1HEA1V2BHYFPIJNP2Y3HNV05BFVZDFZ0E&" +
                        "client_secret=M1BDWESYNYZOETXW1OFWMVRVW4CPJV2IWIRWJE3FSUWHDZFQ&" +
                        "v=20160907&ll="+$rootScope.latitude+","+$rootScope.longitude+"&query="+$scope.type+"")
                        .success(function(data){
                            results = data;
                           displayData(results);
                        });
                }
            });
        }
        getLocation();
        $scope.$watchCollection("marker.coords", function (newVal, oldVal) {
            if (_.isEqual(newVal, oldVal))
                return;
            $scope.coordsUpdates++;
        });
});